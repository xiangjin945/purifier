#ifndef __REG_BLE_EM_WPB_H_
#define __REG_BLE_EM_WPB_H_

#define REG_BLE_EM_WPB_SIZE 6

#define REG_BLE_EM_WPB_BASE_ADDR 0x00814000


#endif // __REG_BLE_EM_WPB_H_

