#ifndef __REG_UART2_H_
#define __REG_UART2_H_

#define REG_UART2_SIZE 36

#define REG_UART2_BASE_ADDR 0x00806a00


#endif // __REG_UART2_H_

