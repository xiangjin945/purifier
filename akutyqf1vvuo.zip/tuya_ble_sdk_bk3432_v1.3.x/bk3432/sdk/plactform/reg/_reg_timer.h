#ifndef __REG_TIMER_H_
#define __REG_TIMER_H_

#define REG_TIMER_SIZE 16

#define REG_TIMER_BASE_ADDR 0x1000E000


#endif // __REG_TIMER_H_

