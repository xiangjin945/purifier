#ifndef __REG_BLE_EM_CS_H_
#define __REG_BLE_EM_CS_H_

#define REG_BLE_EM_CS_SIZE 92

#define REG_BLE_EM_CS_BASE_ADDR 0x00814000


#endif // __REG_BLE_EM_CS_H_

