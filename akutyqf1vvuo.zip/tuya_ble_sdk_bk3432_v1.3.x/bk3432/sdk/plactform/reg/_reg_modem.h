#ifndef __REG_MODEM_H_
#define __REG_MODEM_H_

#define REG_MODEM_SIZE 85

#define REG_MODEM_BASE_ADDR 0x00000000


#endif // __REG_MODEM_H_

