#ifndef __REG_BLE_EM_WPV_H_
#define __REG_BLE_EM_WPV_H_

#define REG_BLE_EM_WPV_SIZE 6

#define REG_BLE_EM_WPV_BASE_ADDR 0x00814000


#endif // __REG_BLE_EM_WPV_H_

