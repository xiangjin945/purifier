#ifndef __REG_UART_H_
#define __REG_UART_H_

#define REG_UART_SIZE 36

#define REG_UART_BASE_ADDR 0x00806300


#endif // __REG_UART_H_

