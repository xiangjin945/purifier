#ifndef _RC32K_CAL_H_
#define _RC32K_CAL_H_


void user_timer_init(void);


#endif  


